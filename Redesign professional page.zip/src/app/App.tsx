import { useState } from "react";
import * as Tabs from "@radix-ui/react-tabs";
import {
  Share2,
  ChevronLeft,
  Copy,
  Users,
  Zap,
  Trophy,
  Radio,
  Check,
  X,
} from "lucide-react";

/* MARKER-MAKE-KIT-INVOKED */

// ── Types ────────────────────────────────────────────────────────────────────

type PickState = "none" | "selected" | "correct" | "wrong";

interface PlayerOption {
  id: string;
  name: string;
  team: string;
  pick: PickState;
  pct?: number;
}

interface BinaryOption {
  id: string;
  label: string;
  pick: PickState;
  pct: number;
}

interface Question {
  id: string;
  text: string;
  pts: number;
  type: "binary" | "player";
  options: BinaryOption[] | PlayerOption[];
  result: "pending" | "scored" | "noscored";
  earned?: number;
}

// ── Mock data ────────────────────────────────────────────────────────────────

const QUESTIONS: Question[] = [
  {
    id: "q1",
    text: "Who wins Fire5 Esports vs F5 JR?",
    pts: 2,
    type: "binary",
    result: "scored",
    earned: 2,
    options: [
      { id: "fire5", label: "Fire5 Esports", pick: "correct", pct: 100 },
      { id: "f5jr", label: "F5 JR", pick: "none", pct: 0 },
    ] as BinaryOption[],
  },
  {
    id: "q2",
    text: "Who wins Map 1?",
    pts: 2,
    type: "binary",
    result: "noscored",
    earned: 0,
    options: [
      { id: "fire5", label: "Fire5 Esports", pick: "none", pct: 54 },
      { id: "f5jr", label: "F5 JR", pick: "selected", pct: 46 },
    ] as BinaryOption[],
  },
  {
    id: "q3",
    text: "Who has the highest ACS in the match?",
    pts: 2,
    type: "player",
    result: "noscored",
    earned: 0,
    options: [
      { id: "p1", name: "TaVaOg", team: "Fire5 Esports", pick: "none" },
      { id: "p2", name: "Ronnie", team: "Fire5 Esports", pick: "none" },
      { id: "p3", name: "LazyFlash", team: "Fire5 Esports", pick: "wrong", pct: 100 },
      { id: "p4", name: "RoBo", team: "Fire5 Esports", pick: "none" },
      { id: "p5", name: "Acanevargetaace", team: "Fire5 Esports", pick: "none" },
      { id: "p6", name: "casti", team: "F5 JR", pick: "none" },
      { id: "p7", name: "NOOOVAAAA", team: "F5 JR", pick: "none" },
      { id: "p8", name: "mochlix", team: "F5 JR", pick: "none" },
      { id: "p9", name: "pixelprincess", team: "F5 JR", pick: "none" },
      { id: "p10", name: "Krishna Ronaldo", team: "F5 JR", pick: "none" },
    ] as PlayerOption[],
  },
  {
    id: "q4",
    text: "Who is the match MVP?",
    pts: 2,
    type: "player",
    result: "pending",
    options: [
      { id: "p1", name: "TaVaOg", team: "Fire5 Esports", pick: "selected", pct: 100 },
      { id: "p2", name: "Ronnie", team: "Fire5 Esports", pick: "none" },
      { id: "p3", name: "LazyFlash", team: "Fire5 Esports", pick: "none" },
      { id: "p4", name: "RoBo", team: "Fire5 Esports", pick: "none" },
      { id: "p5", name: "Acanevargetaace", team: "Fire5 Esports", pick: "none" },
      { id: "p6", name: "casti", team: "F5 JR", pick: "none" },
      { id: "p7", name: "NOOOVAAAA", team: "F5 JR", pick: "none" },
      { id: "p8", name: "mochlix", team: "F5 JR", pick: "none" },
      { id: "p9", name: "pixelprincess", team: "F5 JR", pick: "none" },
      { id: "p10", name: "Krishna Ronaldo", team: "F5 JR", pick: "none" },
    ] as PlayerOption[],
  },
  {
    id: "q5",
    text: "Will the map reach overtime (12-12)?",
    pts: 2,
    type: "binary",
    result: "scored",
    earned: 2,
    options: [
      { id: "yes", label: "Yes — overtime", pick: "none", pct: 0 },
      { id: "no", label: "No — decided in regulation", pick: "correct", pct: 100 },
    ] as BinaryOption[],
  },
];

// ── Sub-components ───────────────────────────────────────────────────────────

function NavBar() {
  return (
    <nav
      style={{ backgroundColor: "#09090b", borderBottom: "1px solid rgba(255,255,255,0.07)" }}
      className="sticky top-0 z-50 w-full"
    >
      <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded flex items-center justify-center"
            style={{ backgroundColor: "#e02020" }}
          >
            <Trophy size={16} color="#fff" />
          </div>
          <span
            className="hidden sm:block tracking-widest uppercase"
            style={{ color: "#f0f0f2", fontSize: "0.7rem", letterSpacing: "0.2em" }}
          >
            GameForge
          </span>
        </div>

        {/* Nav links */}
        <div className="hidden md:flex items-center gap-6">
          {["Tournaments", "Matches", "Teams", "Stats", "News"].map((item) => (
            <a
              key={item}
              href="#"
              style={{
                color: "#8a8a96",
                fontSize: "0.75rem",
                letterSpacing: "0.08em",
                textDecoration: "none",
              }}
              className="uppercase hover:text-white transition-colors"
            >
              {item}
            </a>
          ))}
        </div>

        {/* Avatar */}
        <div className="flex items-center gap-2">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ backgroundColor: "#e02020", fontSize: "0.7rem", color: "#fff", letterSpacing: "0.05em" }}
          >
            TS
          </div>
        </div>
      </div>
    </nav>
  );
}

function TournamentHeader() {
  return (
    <div
      className="rounded-xl p-5 flex items-start gap-4"
      style={{ backgroundColor: "#141416", border: "1px solid rgba(255,255,255,0.08)" }}
    >
      <div
        className="w-12 h-12 rounded-lg flex items-center justify-center shrink-0"
        style={{ backgroundColor: "#1e1e22", border: "1px solid rgba(255,255,255,0.1)" }}
      >
        <Trophy size={22} style={{ color: "#e02020" }} />
      </div>

      <div className="flex-1 min-w-0">
        <p style={{ color: "#e02020", fontSize: "0.65rem", letterSpacing: "0.15em" }} className="uppercase mb-1">
          Tournament
        </p>
        <h1 style={{ color: "#f0f0f2", letterSpacing: "0.02em" }} className="mb-1">
          yyyyyyy
        </h1>
        <p style={{ color: "#8a8a96", fontSize: "0.8rem" }} className="mb-3">yyyy</p>
        <div className="flex flex-wrap items-center gap-2">
          <span style={{ color: "#8a8a96", fontSize: "0.75rem" }}>8/13/2026</span>
          <span style={{ color: "rgba(255,255,255,0.2)" }}>·</span>
          <Badge variant="neutral">mum</Badge>
          <Badge variant="offline">Offline</Badge>
          <Badge variant="live">
            <span
              className="inline-block w-1.5 h-1.5 rounded-full mr-1.5 animate-pulse"
              style={{ backgroundColor: "#e02020" }}
            />
            LIVE
          </Badge>
        </div>
      </div>

      <button
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg transition-colors shrink-0"
        style={{
          backgroundColor: "#1e1e22",
          border: "1px solid rgba(255,255,255,0.1)",
          color: "#f0f0f2",
          fontSize: "0.75rem",
        }}
      >
        <Share2 size={13} />
        Share
      </button>
    </div>
  );
}

function Badge({
  variant,
  children,
}: {
  variant: "neutral" | "offline" | "live";
  children: React.ReactNode;
}) {
  const styles: Record<string, React.CSSProperties> = {
    neutral: { backgroundColor: "#1e1e22", color: "#8a8a96", border: "1px solid rgba(255,255,255,0.08)" },
    offline: { backgroundColor: "rgba(139,139,150,0.12)", color: "#8a8a96", border: "1px solid rgba(139,139,150,0.2)" },
    live: { backgroundColor: "rgba(224,32,32,0.12)", color: "#e02020", border: "1px solid rgba(224,32,32,0.3)" },
  };
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded"
      style={{ fontSize: "0.68rem", letterSpacing: "0.06em", ...styles[variant] }}
    >
      {children}
    </span>
  );
}

function PicksInfoBanner() {
  return (
    <div
      className="rounded-lg px-4 py-3 flex items-start gap-3"
      style={{ backgroundColor: "rgba(224,32,32,0.08)", border: "1px solid rgba(224,32,32,0.2)" }}
    >
      <Zap size={15} style={{ color: "#e02020", marginTop: "1px", flexShrink: 0 }} />
      <p style={{ color: "#f0f0f2", fontSize: "0.82rem", lineHeight: "1.5" }}>
        <strong style={{ color: "#e02020" }}>7 picks left</strong> of 10. Each question you answer
        uses one pick — changing an answer before lock is free.{" "}
        <a href="#" style={{ color: "#e02020", textDecoration: "underline" }}>
          Invite friends to unlock more.
        </a>
      </p>
    </div>
  );
}

function InviteCard() {
  const [copied, setCopied] = useState(false);
  const url = "http://localhost:5173/login?ref=a6c1dc3d9";

  function handleCopy() {
    navigator.clipboard.writeText(url).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div
      className="rounded-xl p-4"
      style={{ backgroundColor: "#141416", border: "1px solid rgba(255,255,255,0.08)" }}
    >
      <div className="flex items-center gap-2 mb-1">
        <Users size={14} style={{ color: "#e02020" }} />
        <span style={{ color: "#f0f0f2", fontSize: "0.82rem" }} className="font-medium">
          Invite &amp; unlock picks
        </span>
      </div>
      <p style={{ color: "#8a8a96", fontSize: "0.76rem", lineHeight: "1.5" }} className="mb-3">
        Each verified friend unlocks <strong style={{ color: "#f0f0f2" }}>+5 picks</strong>. 3 more
        verified invites — unlimited.
      </p>
      <div className="flex gap-2">
        <div
          className="flex-1 rounded-lg px-3 py-2 truncate"
          style={{ backgroundColor: "#0c0c0e", border: "1px solid rgba(255,255,255,0.1)", color: "#8a8a96", fontSize: "0.75rem" }}
        >
          {url}
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all"
          style={{
            backgroundColor: copied ? "rgba(34,197,94,0.15)" : "#e02020",
            border: copied ? "1px solid rgba(34,197,94,0.3)" : "1px solid #e02020",
            color: copied ? "#22c55e" : "#fff",
            fontSize: "0.75rem",
            whiteSpace: "nowrap",
          }}
        >
          {copied ? <Check size={13} /> : <Copy size={13} />}
          {copied ? "Copied!" : "Copy"}
        </button>
      </div>
      <p style={{ color: "#8a8a96", fontSize: "0.72rem" }} className="mt-2">
        0 / 3 verified
      </p>
    </div>
  );
}

function MatchHeader() {
  return (
    <div
      className="rounded-xl px-5 py-4 flex items-center justify-between"
      style={{ backgroundColor: "#141416", border: "1px solid rgba(255,255,255,0.08)" }}
    >
      <div>
        <p style={{ color: "#8a8a96", fontSize: "0.7rem", letterSpacing: "0.1em" }} className="uppercase mb-1">
          Match Predictions
        </p>
        <h3 style={{ color: "#f0f0f2" }}>
          <span style={{ color: "#e02020" }}>Fire5 Esports</span>
          <span style={{ color: "#8a8a96", margin: "0 8px" }}>vs</span>
          F5 JR
        </h3>
      </div>
      <div className="flex items-center gap-2">
        <span
          className="px-2 py-0.5 rounded"
          style={{ backgroundColor: "#1e1e22", color: "#8a8a96", fontSize: "0.68rem", letterSpacing: "0.08em" }}
        >
          QUARTER FINALS
        </span>
        <span style={{ color: "rgba(255,255,255,0.2)" }}>→</span>
        <span
          className="px-2 py-0.5 rounded"
          style={{ backgroundColor: "rgba(224,32,32,0.12)", color: "#e02020", fontSize: "0.68rem", letterSpacing: "0.08em", border: "1px solid rgba(224,32,32,0.25)" }}
        >
          FINAL
        </span>
      </div>
    </div>
  );
}

function BinaryQuestion({ question }: { question: Question }) {
  const options = question.options as BinaryOption[];
  return (
    <QuestionWrapper question={question}>
      <div className="grid grid-cols-2 gap-3">
        {options.map((opt) => (
          <BinaryOptionCard key={opt.id} opt={opt} />
        ))}
      </div>
    </QuestionWrapper>
  );
}

function BinaryOptionCard({ opt }: { opt: BinaryOption }) {
  const isCorrect = opt.pick === "correct";
  const isWrong = opt.pick === "wrong";
  const isSelected = opt.pick === "selected";

  let borderColor = "rgba(255,255,255,0.08)";
  let bgColor = "#1e1e22";
  let labelColor = "#f0f0f2";
  let barColor = "#3a3a42";

  if (isCorrect) {
    borderColor = "rgba(34,197,94,0.4)";
    bgColor = "rgba(34,197,94,0.08)";
    barColor = "#22c55e";
    labelColor = "#22c55e";
  } else if (isWrong) {
    borderColor = "rgba(224,32,32,0.4)";
    bgColor = "rgba(224,32,32,0.08)";
    barColor = "#e02020";
    labelColor = "#e02020";
  } else if (isSelected) {
    borderColor = "rgba(224,32,32,0.4)";
    bgColor = "rgba(224,32,32,0.06)";
  }

  return (
    <div
      className="rounded-lg p-3 relative overflow-hidden cursor-pointer transition-all"
      style={{ border: `1px solid ${borderColor}`, backgroundColor: bgColor }}
    >
      {/* progress bar background */}
      {opt.pct > 0 && (
        <div
          className="absolute inset-y-0 left-0 opacity-20 rounded-l-lg"
          style={{ width: `${opt.pct}%`, backgroundColor: barColor, transition: "width 0.6s ease" }}
        />
      )}
      <div className="relative flex items-center justify-between">
        <span style={{ color: labelColor, fontSize: "0.82rem" }}>{opt.label}</span>
        <div className="flex items-center gap-2">
          <span style={{ color: "#8a8a96", fontSize: "0.72rem" }}>{opt.pct}%</span>
          {isCorrect && <Check size={13} style={{ color: "#22c55e" }} />}
          {isWrong && <X size={13} style={{ color: "#e02020" }} />}
        </div>
      </div>
    </div>
  );
}

function PlayerQuestion({ question }: { question: Question }) {
  const options = question.options as PlayerOption[];
  return (
    <QuestionWrapper question={question}>
      <div className="grid grid-cols-2 gap-2">
        {options.map((opt) => (
          <PlayerOptionCard key={opt.id} opt={opt} />
        ))}
      </div>
    </QuestionWrapper>
  );
}

function PlayerOptionCard({ opt }: { opt: PlayerOption }) {
  const isCorrect = opt.pick === "correct";
  const isWrong = opt.pick === "wrong";
  const isSelected = opt.pick === "selected";

  let borderColor = "rgba(255,255,255,0.08)";
  let bgColor = "#1e1e22";
  let nameColor = "#f0f0f2";
  let Icon: React.ReactNode = null;

  if (isCorrect) {
    borderColor = "rgba(34,197,94,0.35)";
    bgColor = "rgba(34,197,94,0.07)";
    nameColor = "#22c55e";
    Icon = <Check size={12} style={{ color: "#22c55e" }} />;
  } else if (isWrong) {
    borderColor = "rgba(224,32,32,0.35)";
    bgColor = "rgba(224,32,32,0.07)";
    nameColor = "#e02020";
    Icon = <X size={12} style={{ color: "#e02020" }} />;
  } else if (isSelected) {
    borderColor = "rgba(224,32,32,0.35)";
    bgColor = "rgba(224,32,32,0.06)";
    nameColor = "#f0f0f2";
  }

  return (
    <div
      className="flex items-center justify-between rounded-lg px-3 py-2.5 cursor-pointer transition-all"
      style={{ border: `1px solid ${borderColor}`, backgroundColor: bgColor }}
    >
      <div className="min-w-0">
        <p style={{ color: nameColor, fontSize: "0.8rem" }} className="truncate">
          {opt.name}
        </p>
        <p style={{ color: "#8a8a96", fontSize: "0.68rem" }} className="truncate">
          {opt.team}
        </p>
      </div>
      {Icon && <span className="shrink-0 ml-2">{Icon}</span>}
      {opt.pct !== undefined && !isCorrect && !isWrong && (
        <span style={{ color: "#8a8a96", fontSize: "0.68rem" }} className="shrink-0 ml-2">
          {opt.pct}%
        </span>
      )}
      {(isCorrect || isWrong) && opt.pct !== undefined && (
        <span style={{ color: "#8a8a96", fontSize: "0.68rem" }} className="shrink-0 ml-2">
          {opt.pct}%
        </span>
      )}
    </div>
  );
}

function QuestionWrapper({
  question,
  children,
}: {
  question: Question;
  children: React.ReactNode;
}) {
  return (
    <div
      className="rounded-xl p-4"
      style={{ backgroundColor: "#141416", border: "1px solid rgba(255,255,255,0.08)" }}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <h4 style={{ color: "#f0f0f2", fontSize: "0.88rem", lineHeight: "1.4" }}>{question.text}</h4>
        <div className="flex items-center gap-2 shrink-0">
          {question.result === "scored" && (
            <span
              className="px-2 py-0.5 rounded"
              style={{ backgroundColor: "rgba(34,197,94,0.12)", color: "#22c55e", fontSize: "0.68rem", border: "1px solid rgba(34,197,94,0.25)" }}
            >
              +{question.earned} pts
            </span>
          )}
          {question.result === "noscored" && (
            <span
              className="px-2 py-0.5 rounded"
              style={{ backgroundColor: "rgba(139,139,150,0.1)", color: "#8a8a96", fontSize: "0.68rem" }}
            >
              No points
            </span>
          )}
          <span
            className="px-2 py-0.5 rounded"
            style={{ backgroundColor: "#1e1e22", color: "#8a8a96", fontSize: "0.68rem" }}
          >
            {question.pts} pts
          </span>
        </div>
      </div>
      {children}
    </div>
  );
}

// ── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [picksTab, setPicksTab] = useState("play");

  return (
    <div style={{ backgroundColor: "#0c0c0e", minHeight: "100vh" }}>
      <NavBar />

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Back */}
        <a
          href="#"
          className="inline-flex items-center gap-1.5 mb-5 transition-colors"
          style={{ color: "#8a8a96", fontSize: "0.78rem", textDecoration: "none" }}
        >
          <ChevronLeft size={14} />
          Back to Tournaments
        </a>

        {/* Tournament header */}
        <div className="mb-5">
          <TournamentHeader />
        </div>

        {/* Page tabs */}
        <Tabs.Root defaultValue="pickems">
          <Tabs.List
            className="flex gap-1 mb-6 overflow-x-auto"
            style={{ borderBottom: "1px solid rgba(255,255,255,0.08)", paddingBottom: "0" }}
          >
            {[
              { value: "overview", label: "Overview" },
              { value: "matches", label: "Matches", count: 2 },
              { value: "bracket", label: "Bracket" },
              { value: "standings", label: "Standings" },
              { value: "teams", label: "Teams", count: 3 },
              { value: "news", label: "News", count: 2 },
              { value: "pickems", label: "Pickems" },
            ].map((tab) => (
              <Tabs.Trigger
                key={tab.value}
                value={tab.value}
                className="relative flex items-center gap-1.5 px-3 pb-3 pt-1 whitespace-nowrap transition-colors"
                style={{
                  color: "#8a8a96",
                  fontSize: "0.8rem",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  outline: "none",
                }}
              >
                {/* active indicator handled via inline style override */}
                <TabTriggerInner tab={tab} />
              </Tabs.Trigger>
            ))}
          </Tabs.List>

          <Tabs.Content value="pickems">
            <PickemsContent picksTab={picksTab} setPicksTab={setPicksTab} />
          </Tabs.Content>
          {["overview", "matches", "bracket", "standings", "teams", "news"].map((v) => (
            <Tabs.Content key={v} value={v}>
              <div
                className="rounded-xl p-8 text-center"
                style={{ backgroundColor: "#141416", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <p style={{ color: "#8a8a96", fontSize: "0.85rem" }}>
                  {v.charAt(0).toUpperCase() + v.slice(1)} content coming soon.
                </p>
              </div>
            </Tabs.Content>
          ))}
        </Tabs.Root>
      </div>
    </div>
  );
}

// Separate component so we can use hooks-friendly active detection
function TabTriggerInner({ tab }: { tab: { value: string; label: string; count?: number } }) {
  return (
    <>
      <style>{`
        [data-radix-tabs-trigger][data-state="active"] { color: #f0f0f2 !important; }
        [data-radix-tabs-trigger][data-state="active"]::after {
          content: '';
          position: absolute;
          bottom: -1px;
          left: 0; right: 0;
          height: 2px;
          background: #e02020;
          border-radius: 2px 2px 0 0;
        }
      `}</style>
      {tab.label}
      {tab.count !== undefined && (
        <span
          className="inline-flex items-center justify-center w-4 h-4 rounded-full"
          style={{ backgroundColor: "#252528", color: "#8a8a96", fontSize: "0.6rem" }}
        >
          {tab.count}
        </span>
      )}
    </>
  );
}

// ── Leaderboard ──────────────────────────────────────────────────────────────

const LEADERBOARD_DATA = [
  { rank: 1, name: "TaVaOg_fan", avatar: "TF", correct: 8, wrong: 2, pts: 14 },
  { rank: 2, name: "xBlazeHunter", avatar: "XB", correct: 7, wrong: 3, pts: 12 },
  { rank: 3, name: "NightOwl99", avatar: "NO", correct: 7, wrong: 3, pts: 10 },
  { rank: 4, name: "TS", avatar: "TS", correct: 5, wrong: 5, pts: 6, isMe: true },
  { rank: 5, name: "LazyFlashFan", avatar: "LF", correct: 5, wrong: 5, pts: 6 },
  { rank: 6, name: "RoBoSupporter", avatar: "RS", correct: 4, wrong: 6, pts: 4 },
  { rank: 7, name: "F5JR_Ultra", avatar: "FU", correct: 3, wrong: 7, pts: 2 },
  { rank: 8, name: "pixelwatcher", avatar: "PW", correct: 2, wrong: 8, pts: 2 },
  { rank: 9, name: "mochlix_hype", avatar: "MH", correct: 2, wrong: 8, pts: 0 },
  { rank: 10, name: "casti_fanboy", avatar: "CF", correct: 1, wrong: 9, pts: 0 },
];

function Leaderboard() {
  const top3 = LEADERBOARD_DATA.slice(0, 3);
  const rest = LEADERBOARD_DATA.slice(3);

  return (
    <div className="space-y-4">
      {/* Podium */}
      <div className="grid grid-cols-3 gap-3 mb-2">
        {[top3[1], top3[0], top3[2]].map((player, i) => {
          const podiumRank = [2, 1, 3][i];
          const isFirst = podiumRank === 1;
          const medalColors: Record<number, { bg: string; text: string; border: string }> = {
            1: { bg: "rgba(234,179,8,0.1)", text: "#eab308", border: "rgba(234,179,8,0.3)" },
            2: { bg: "rgba(148,163,184,0.1)", text: "#94a3b8", border: "rgba(148,163,184,0.25)" },
            3: { bg: "rgba(180,83,9,0.1)", text: "#b45309", border: "rgba(180,83,9,0.25)" },
          };
          const c = medalColors[podiumRank];
          return (
            <div
              key={player.rank}
              className="rounded-xl p-4 flex flex-col items-center gap-2 text-center"
              style={{
                backgroundColor: isFirst ? "rgba(234,179,8,0.05)" : "#141416",
                border: `1px solid ${c.border}`,
                marginTop: isFirst ? "0" : "16px",
              }}
            >
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{ backgroundColor: c.bg, border: `2px solid ${c.border}`, color: c.text, fontSize: "0.72rem" }}
              >
                {player.avatar}
              </div>
              <div>
                <p style={{ color: "#f0f0f2", fontSize: "0.8rem" }} className="truncate max-w-[80px]">{player.name}</p>
                <p style={{ color: c.text, fontSize: "0.68rem", letterSpacing: "0.06em" }}>#{podiumRank}</p>
              </div>
              <div
                className="px-3 py-1 rounded-lg"
                style={{ backgroundColor: c.bg, border: `1px solid ${c.border}` }}
              >
                <p style={{ color: c.text, fontSize: "0.88rem" }}>{player.pts} pts</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1" style={{ color: "#22c55e", fontSize: "0.7rem" }}>
                  <Check size={11} />{player.correct}
                </span>
                <span className="flex items-center gap-1" style={{ color: "#e02020", fontSize: "0.7rem" }}>
                  <X size={11} />{player.wrong}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table */}
      <div
        className="rounded-xl overflow-hidden"
        style={{ backgroundColor: "#141416", border: "1px solid rgba(255,255,255,0.08)" }}
      >
        {/* Header */}
        <div
          className="grid px-4 py-2.5"
          style={{
            gridTemplateColumns: "2rem 1fr 5rem 5rem 5rem",
            borderBottom: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          {["#", "Player", "Correct", "Wrong", "Points"].map((h) => (
            <span key={h} style={{ color: "#8a8a96", fontSize: "0.68rem", letterSpacing: "0.1em" }} className="uppercase">
              {h}
            </span>
          ))}
        </div>

        {/* Rows */}
        {rest.map((player, idx) => (
          <div
            key={player.rank}
            className="grid items-center px-4 py-3 transition-colors"
            style={{
              gridTemplateColumns: "2rem 1fr 5rem 5rem 5rem",
              borderBottom: idx < rest.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none",
              backgroundColor: player.isMe ? "rgba(224,32,32,0.05)" : "transparent",
            }}
          >
            <span style={{ color: "#8a8a96", fontSize: "0.78rem" }}>{player.rank}</span>

            <div className="flex items-center gap-2 min-w-0">
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center shrink-0"
                style={{
                  backgroundColor: player.isMe ? "rgba(224,32,32,0.2)" : "#1e1e22",
                  color: player.isMe ? "#e02020" : "#8a8a96",
                  fontSize: "0.6rem",
                  border: player.isMe ? "1px solid rgba(224,32,32,0.35)" : "1px solid rgba(255,255,255,0.08)",
                }}
              >
                {player.avatar}
              </div>
              <span style={{ color: player.isMe ? "#f0f0f2" : "#c0c0cc", fontSize: "0.82rem" }} className="truncate">
                {player.name}
                {player.isMe && (
                  <span style={{ color: "#e02020", fontSize: "0.65rem", marginLeft: "6px" }}>YOU</span>
                )}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <Check size={12} style={{ color: "#22c55e" }} />
              <span style={{ color: "#22c55e", fontSize: "0.8rem" }}>{player.correct}</span>
            </div>

            <div className="flex items-center gap-1.5">
              <X size={12} style={{ color: "#e02020" }} />
              <span style={{ color: "#e02020", fontSize: "0.8rem" }}>{player.wrong}</span>
            </div>

            <div className="flex items-center gap-1.5">
              <span style={{ color: "#f0f0f2", fontSize: "0.82rem" }}>{player.pts}</span>
              <span style={{ color: "#8a8a96", fontSize: "0.7rem" }}>pts</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PickemsContent({
  picksTab,
  setPicksTab,
}: {
  picksTab: string;
  setPicksTab: (v: string) => void;
}) {
  return (
    <div className="space-y-4">
      {/* Sub-tab: Play / Leaderboard */}
      <div className="flex gap-2">
        {["play", "leaderboard"].map((t) => (
          <button
            key={t}
            onClick={() => setPicksTab(t)}
            className="px-4 py-1.5 rounded-lg transition-all capitalize"
            style={{
              backgroundColor: picksTab === t ? "#e02020" : "#1e1e22",
              color: picksTab === t ? "#fff" : "#8a8a96",
              border: picksTab === t ? "1px solid #e02020" : "1px solid rgba(255,255,255,0.08)",
              fontSize: "0.8rem",
              cursor: "pointer",
            }}
          >
            {t === "leaderboard" && <Radio size={12} style={{ display: "inline", marginRight: "6px" }} />}
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {picksTab === "play" && (
        <>
          <PicksInfoBanner />
          <InviteCard />
          <MatchHeader />
          {QUESTIONS.map((q) =>
            q.type === "binary" ? (
              <BinaryQuestion key={q.id} question={q} />
            ) : (
              <PlayerQuestion key={q.id} question={q} />
            )
          )}
        </>
      )}

      {picksTab === "leaderboard" && <Leaderboard />}
    </div>
  );
}
