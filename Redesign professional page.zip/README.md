
  # Redesign professional page

  This is a code bundle for Redesign professional page. The original project is available at https://www.figma.com/design/Z0tobGUYghDPyvN44u4C1Q/Redesign-professional-page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  